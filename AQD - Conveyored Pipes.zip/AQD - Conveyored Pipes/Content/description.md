[img]https://i.imgur.com/fVVaDCS.gif[/img]

[h1]Current version: [b]1.0[/b][/h1]
[i]Please refer to the [url=https://steamcommunity.com/sharedfiles/filedetails/changelog/]changelog[/url] for patch notes.[/i]

[img]https://i.imgur.com/cdhLXnQ.png[/img]
[quote]
This is a very small mod that makes the new pipe blocks added in patch 1.206 able to transport both gases and items that can be transported through small conveyors.
[/quote]

[h1][b]AQD - A Quantum of Depth[/b] is a project of mine, encompassing multiple small and larger mods aimed at improving the gameplay experience and eventually overhauling larger parts of the game:[/h1]

[url=https://steamcommunity.com/sharedfiles/filedetails/?id=1808547374][img]https://raw.githubusercontent.com/enenra/aqdse/master/collection.jpg[/img][/url]

[img]https://i.imgur.com/5nbiNLV.png[/img]
Replaces all pipe block models and alters their definitions to allow them to transport (small conveyor) items and gases. Also alters the Junction Box to be an adapter from the normal large grid conveyor to the pipes.

[url=https://discord.gg/QtyCsBr][img]https://i.imgur.com/l8exfyn.png[/img][/url]
[url=https://github.com/enenra/aqdse][img]https://i.imgur.com/T7AtPhP.png[/img][/url]

[url=https://steamcommunity.com/workshop/discussions/18446744073709551615/2793874853443195941/?appid=244850][img]https://raw.githubusercontent.com/enenra/aqdse/master/usage_guidelines.png[/img][/url]